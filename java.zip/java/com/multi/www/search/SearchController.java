package com.multi.www.search;

public class SearchController {

}
