package com.multi.www.search;

public class SearchService {

}
