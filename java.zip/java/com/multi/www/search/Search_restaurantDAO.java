package com.multi.www.search;

public class Search_restaurantDAO {

}
